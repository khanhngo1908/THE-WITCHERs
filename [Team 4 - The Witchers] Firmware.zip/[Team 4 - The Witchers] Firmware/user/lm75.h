/*
 * lm75.h
 *
 *  Created on: 18 thg 2, 2022
 *      Author: Ngo Minh Khanh
 */

#ifndef USER_LM75_H_
#define USER_LM75_H_

#include "stdint.h"

#define LM75_11BIT
#define LM75_ADDRESS        0x48

#define LM75_TEMPERATURE    0x00
#define LM75_CONFIGURATION  0x01
#define LM75_THYST          0x02
#define LM75_TOS            0x03

#define LM75_MAX	51
#define LM75_MIN	20
//uint8_t a = 9;

#define ABS(x)   ((x) > 0 ? (x) : -(x))

//----------------------------------------------------------------------------//

/**
 * @brief      Read config register of LM75
 *
 * @return     Value of LM75 config register
 */
uint8_t LM75_ReadConfig (void);

/**
 * @brief      Read 9-bit format temperature from register
 *
 * @param[in]  reg   -   address of temperature register
 * @return     Value of temperature
 */
void LM75_ReadTemperature_9BitReg (uint16_t *value);

/**
 * @brief      Read 11-bit format temperature from register
 *
 * @param[in]  reg   -   address of temperature register
 * @return     Value of temperature
 */
void LM75_ReadTemperature_11BitReg (uint16_t *value);

/**
 * @brief      Config LM75 into sleep mode (shutdown)
 *
 * @param[in]  mode    - 0: normal (defaul); 1: shutdown
 * @return     none
 */
void LM75_Shutdown ();

void LM75_Continue ();

uint8_t LM75_FloatToOneByte (float T);

float LM75_OneByteToFloat (uint8_t T);

/**
 * @brief    Read temparature
 *
 * @return   value of temperature
 */
float LM75_ReadTemperature (void);



#endif /* USER_LM75_H_ */
